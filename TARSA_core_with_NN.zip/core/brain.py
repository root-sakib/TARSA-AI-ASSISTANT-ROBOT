from core.lang import detect_lang
from core.identity import who_are_you
from core.user_profile import who_is_user, get_user_field
from core.memory_db import (
    init_db,
    get_exact,
    get_similar,
    store_qa
)
from core.ollama_client import ask_answer, make_summary
from core.embeddings import embed, cosine

# 🔥 database initialize (একবারই হবে)
init_db()


def generate_response(user_input: str) -> str:
    """
    TARSA brain:
    1. USER self questions (my / me)
    2. Robot identity
    3. User identity (do you know me)
    4. Exact memory
    5. Similar memory
    6. Ollama fallback
    7. Learn & store
    """

    text = user_input.strip()
    text_lower = text.lower()
    lang = detect_lang(text)

    # ==================================================
    # 1️⃣ USER self questions (VERY IMPORTANT)
    # ==================================================
    if "my name" in text_lower:
        name = get_user_field("name")
        if name:
            return f"Your name is {name}."

    if "my education" in text_lower:
        edu = get_user_field("education")
        if edu:
            return f"Your education is: {edu}."

    if (
        "my current study" in text_lower
        or "what am i studying" in text_lower
        or "what am i studying now" in text_lower
    ):
        study = get_user_field("current_study")
        if study:
            return f"You are currently studying {study}."

    # ==================================================
    # 2️⃣ Robot identity
    # ==================================================
    if "who are you" in text_lower or "tumi ke" in text_lower or "apni ke" in text_lower:
        return who_are_you(lang)

    # ==================================================
    # 3️⃣ User identity (general)
    # ==================================================
    if (
        "do you know me" in text_lower
        or "who am i" in text_lower
        or "amake chino" in text_lower
        or "ami ke" in text_lower
    ):
        return who_is_user(lang)

    # ==================================================
# 4️⃣ Retrieve memory candidates (exact + similar)
# ==================================================
exact = get_exact(text)
similar = None if exact else get_similar(text)

# Prepare NN features for a principled decision
from core.memory_db import get_recent_embeddings, get_memory_size, store_interaction
from core.nn.features import build_feature_vector, feature_dim
from core.nn.policy_net import PolicyNet
from core.nn.uncertainty import should_query_oracle
import torch
import os

lang_id = 1 if lang == "bn" else (0 if lang == "en" else 2)

# Similarity stats against recent memory
recent_vecs = get_recent_embeddings(limit_scan=50)
if recent_vecs:
    qv = embed(text)
    sims = [cosine(qv, v) for v in recent_vecs]
    best_sim = float(max(sims)) if sims else 0.0
    mean_sim = float(sum(sims) / max(1, len(sims)))
    # quick std
    m = mean_sim
    std_sim = float((sum((s - m) ** 2 for s in sims) / max(1, len(sims))) ** 0.5)
    topk = int(len(sims))
else:
    best_sim = mean_sim = std_sim = 0.0
    topk = 0

mem_size = get_memory_size()
feats = build_feature_vector(
    lang_id=lang_id,
    exact_found=bool(exact),
    best_sim=best_sim,
    mean_sim=mean_sim,
    std_sim=std_sim,
    topk=topk,
    memory_size=mem_size,
)

# Load policy checkpoint if available, otherwise fall back to a safe heuristic
ckpt_path = "data/policy.pt"
policy = PolicyNet(in_dim=feature_dim())
if os.path.exists(ckpt_path):
    try:
        policy.load_state_dict(torch.load(ckpt_path, map_location="cpu"))
        policy.eval()
    except Exception:
        pass

out = policy.decide(feats)
# extra math-based uncertainty gating (professor-friendly)
probs = torch.tensor([out.action_probs[a] for a in policy.ACTIONS], dtype=torch.float32)
oracle_needed = should_query_oracle(probs) or (out.action == "query_ollama")

# ==================================================
# 5️⃣ If confident, answer from memory
# ==================================================
if exact and (not oracle_needed):
    store_interaction(
        question=text, lang=lang,
        exact_found=True,
        best_sim=best_sim, mean_sim=mean_sim, std_sim=std_sim, topk=topk,
        memory_size=mem_size,
        chosen_action="use_memory",
        action_id=0,
        used_oracle=False,
        reward=0.0,
        weight=1.0,
        notes="exact"
    )
    return exact["summary"]

if similar and (not oracle_needed) and similar.get("score", 0.0) >= 0.75:
    store_interaction(
        question=text, lang=lang,
        exact_found=False,
        best_sim=best_sim, mean_sim=mean_sim, std_sim=std_sim, topk=topk,
        memory_size=mem_size,
        chosen_action="use_memory",
        action_id=0,
        used_oracle=False,
        reward=0.0,
        weight=1.0,
        notes=f"similar:{similar.get('score',0.0):.3f}"
    )
    return similar["summary"]

# ==================================================
# 6️⃣ Ask user to clarify (optional action)
# ==================================================
if out.action == "ask_clarify" and (not exact) and (not similar):
    store_interaction(
        question=text, lang=lang,
        exact_found=False,
        best_sim=best_sim, mean_sim=mean_sim, std_sim=std_sim, topk=topk,
        memory_size=mem_size,
        chosen_action="ask_clarify",
        action_id=2,
        used_oracle=False,
        reward=0.0,
        weight=1.0,
        notes="policy"
    )
    if lang == "bn":
        return "আপনি একটু স্পষ্ট করে বলবেন? আপনি ঠিক কী জানতে চান?"
    return "Could you clarify what exactly you want to know?"

# ==================================================
# 7️⃣ Ollama fallback (oracle)
# ==================================================
full_answer = ask_answer(text, lang)

# ==================================================
# 8️⃣ Consolidate: store oracle output into editable memory
# ==================================================
summary = make_summary(text, full_answer, lang)

if summary and not summary.lower().startswith("ollama error"):
    store_qa(
        question=text,
        lang=lang,
        answer_full=full_answer,
        answer_summary=summary,
        source="ollama",
        confidence=0.4
    )

store_interaction(
    question=text, lang=lang,
    exact_found=bool(exact),
    best_sim=best_sim, mean_sim=mean_sim, std_sim=std_sim, topk=topk,
    memory_size=mem_size,
    chosen_action="query_ollama",
    action_id=1,
    used_oracle=True,
    reward=0.0,
    weight=1.0,
    notes="oracle"
)

return summary if summary else full_answer
