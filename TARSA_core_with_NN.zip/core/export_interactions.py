"""Export interaction logs to JSONL/CSV for analysis.

Usage:
  python -m core.export_interactions
"""

from __future__ import annotations

import csv
import json
import sqlite3
from core.memory_db import DB_PATH, init_db


def main():
    init_db()
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        """SELECT ts, question, lang, exact_found, best_sim, mean_sim, std_sim, topk, memory_size,
                 chosen_action, action_id, used_oracle, reward, weight, notes
           FROM interactions ORDER BY id ASC"""
    )
    rows = cur.fetchall()
    conn.close()

    # JSONL
    with open("data/interactions.jsonl", "w", encoding="utf-8") as f:
        for r in rows:
            obj = {
                "ts": r[0],
                "question": r[1],
                "lang": r[2],
                "exact_found": r[3],
                "best_sim": r[4],
                "mean_sim": r[5],
                "std_sim": r[6],
                "topk": r[7],
                "memory_size": r[8],
                "chosen_action": r[9],
                "action_id": r[10],
                "used_oracle": r[11],
                "reward": r[12],
                "weight": r[13],
                "notes": r[14],
            }
            f.write(json.dumps(obj, ensure_ascii=False) + "\n")

    # CSV
    with open("data/interactions.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow([
            "ts","question","lang","exact_found","best_sim","mean_sim","std_sim","topk","memory_size",
            "chosen_action","action_id","used_oracle","reward","weight","notes"
        ])
        w.writerows(rows)

    print("Exported to data/interactions.jsonl and data/interactions.csv")


if __name__ == "__main__":
    main()
