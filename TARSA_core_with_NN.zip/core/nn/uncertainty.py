"""Uncertainty estimation utilities (math-based gating)."""

from __future__ import annotations

import math
from typing import Dict, Tuple

import torch


def entropy(probs: torch.Tensor, eps: float = 1e-12) -> float:
    """Shannon entropy of a probability vector."""
    p = probs.clamp(min=eps)
    h = -float(torch.sum(p * torch.log(p)).item())
    return h


def margin(probs: torch.Tensor) -> float:
    """Difference between top-1 and top-2 probabilities."""
    vals, _ = torch.sort(probs, descending=True)
    if vals.numel() < 2:
        return 1.0
    return float((vals[0] - vals[1]).item())


def should_query_oracle(
    probs: torch.Tensor,
    entropy_threshold: float = 0.9,
    margin_threshold: float = 0.15,
) -> bool:
    """Decision rule: query oracle when model is uncertain."""
    h = entropy(probs)
    m = margin(probs)
    return (h > entropy_threshold) or (m < margin_threshold)
