"""Training loop for PolicyNet.

Training data comes from the interaction log table in SQLite:
  - features (numeric vector)
  - label/action (which action was correct)
  - optional reward/user feedback

This enables:
  - supervised learning on pseudo-labels / user labels
  - continual learning by replaying older transitions
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Dict, List, Tuple

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader

from core.nn.policy_net import PolicyNet


class InteractionDataset(Dataset):
    def __init__(self, rows: List[Dict]):
        self.rows = rows

    def __len__(self) -> int:
        return len(self.rows)

    def __getitem__(self, idx: int):
        r = self.rows[idx]
        x = torch.tensor(r["features"], dtype=torch.float32)
        y = int(r["action_id"])
        w = float(r.get("weight", 1.0))
        return x, y, w


@dataclass
class TrainConfig:
    lr: float = 1e-3
    batch_size: int = 64
    epochs: int = 10
    weight_decay: float = 1e-4
    hidden: int = 128
    dropout: float = 0.1
    device: str = "cpu"


def train_policy(rows: List[Dict], in_dim: int, cfg: TrainConfig) -> PolicyNet:
    ds = InteractionDataset(rows)
    dl = DataLoader(ds, batch_size=cfg.batch_size, shuffle=True)

    model = PolicyNet(in_dim=in_dim, hidden=cfg.hidden, dropout=cfg.dropout).to(cfg.device)
    opt = optim.AdamW(model.parameters(), lr=cfg.lr, weight_decay=cfg.weight_decay)

    # Weighted CE to incorporate user feedback confidence
    ce = nn.CrossEntropyLoss(reduction="none")

    model.train()
    for _ in range(cfg.epochs):
        for x, y, w in dl:
            x = x.to(cfg.device)
            y = y.to(cfg.device)
            w = w.to(cfg.device)

            logits = model(x)
            loss_vec = ce(logits, y) * w
            loss = loss_vec.mean()

            opt.zero_grad()
            loss.backward()
            opt.step()

    return model


def save_checkpoint(model: PolicyNet, path: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    torch.save(model.state_dict(), path)


def load_checkpoint(model: PolicyNet, path: str) -> PolicyNet:
    state = torch.load(path, map_location="cpu")
    model.load_state_dict(state)
    model.eval()
    return model
