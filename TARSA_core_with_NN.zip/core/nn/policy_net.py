"""Trainable decision network (your 'real NN').

The policy network decides whether TARSA should:
  - answer from memory
  - call external oracle (Ollama)
  - ask the user to clarify

This keeps Ollama as a non-authoritative fallback.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


@dataclass
class PolicyOutput:
    action: str                 # "use_memory" | "query_ollama" | "ask_clarify"
    action_probs: Dict[str, float]
    confidence: float           # max prob
    logits: torch.Tensor


class PolicyNet(nn.Module):
    """Simple MLP policy.

    Input: numeric feature vector (no text tokens).
    Output: logits over actions.
    """

    ACTIONS = ("use_memory", "query_ollama", "ask_clarify")

    def __init__(self, in_dim: int, hidden: int = 128, dropout: float = 0.1):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, hidden),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, len(self.ACTIONS)),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)

    @torch.no_grad()
    def decide(self, features: torch.Tensor, temperature: float = 1.0) -> PolicyOutput:
        """Return action + probabilities from a single feature vector."""
        if features.ndim == 1:
            features = features.unsqueeze(0)

        logits = self.forward(features)
        probs = F.softmax(logits / max(1e-6, temperature), dim=-1).squeeze(0)

        probs_list = probs.detach().cpu().tolist()
        action_probs = {a: float(p) for a, p in zip(self.ACTIONS, probs_list)}
        best_i = int(torch.argmax(probs).item())
        action = self.ACTIONS[best_i]
        conf = float(probs[best_i].item())

        return PolicyOutput(action=action, action_probs=action_probs, confidence=conf, logits=logits.squeeze(0))
