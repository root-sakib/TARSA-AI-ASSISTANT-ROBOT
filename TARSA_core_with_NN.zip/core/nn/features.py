"""Feature extraction for PolicyNet.

We intentionally keep features numeric (small MLP),
so the project remains 'your NN' and not another LLM.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional, Tuple

import numpy as np
import torch

from core.embeddings import embed, cosine


@dataclass
class RetrievalStats:
    exact_hit: float
    best_sim: float
    mean_sim: float
    std_sim: float
    topk: int


def compute_retrieval_stats(q: str, candidate_embeddings: list[np.ndarray]) -> RetrievalStats:
    if not candidate_embeddings:
        return RetrievalStats(exact_hit=0.0, best_sim=0.0, mean_sim=0.0, std_sim=0.0, topk=0)

    qv = embed(q)
    sims = [cosine(qv, v) for v in candidate_embeddings]
    arr = np.array(sims, dtype=np.float32)
    return RetrievalStats(
        exact_hit=0.0,
        best_sim=float(arr.max()),
        mean_sim=float(arr.mean()),
        std_sim=float(arr.std()),
        topk=int(len(candidate_embeddings)),
    )


def build_feature_vector(
    lang_id: int,
    exact_found: bool,
    best_sim: float,
    mean_sim: float,
    std_sim: float,
    topk: int,
    memory_size: int,
) -> torch.Tensor:
    """Compact feature vector.

    lang_id: 0=en, 1=bn, 2=other
    """
    x = np.array(
        [
            float(lang_id),
            1.0 if exact_found else 0.0,
            float(best_sim),
            float(mean_sim),
            float(std_sim),
            float(topk),
            float(memory_size),
        ],
        dtype=np.float32,
    )
    return torch.tensor(x, dtype=torch.float32)


def feature_dim() -> int:
    return 7
