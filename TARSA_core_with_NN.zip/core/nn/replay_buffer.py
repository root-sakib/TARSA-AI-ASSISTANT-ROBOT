"""Replay buffer for continual learning (prevents catastrophic forgetting)."""

from __future__ import annotations

import random
from dataclasses import dataclass
from typing import List, Tuple

import torch


@dataclass
class Transition:
    features: torch.Tensor
    action_id: int
    reward: float


class ReplayBuffer:
    def __init__(self, capacity: int = 5000, seed: int = 42):
        self.capacity = int(capacity)
        self.rng = random.Random(seed)
        self.data: List[Transition] = []

    def push(self, t: Transition) -> None:
        if len(self.data) >= self.capacity:
            # FIFO
            self.data.pop(0)
        self.data.append(t)

    def sample(self, batch_size: int = 32) -> List[Transition]:
        if len(self.data) <= batch_size:
            return list(self.data)
        return self.rng.sample(self.data, batch_size)

    def __len__(self) -> int:
        return len(self.data)
