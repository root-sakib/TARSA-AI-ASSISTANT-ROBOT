"""CLI to train PolicyNet from logged interactions.

Usage:
  python -m core.train_policy_cli

After training, a checkpoint is saved to data/policy.pt
"""

from __future__ import annotations

from core.memory_db import init_db, load_interactions
from core.nn.features import feature_dim
from core.nn.trainer import TrainConfig, train_policy, save_checkpoint


def main():
    init_db()
    rows = load_interactions(limit=5000)
    if not rows:
        print("No interactions found. Run TARSA for a while to collect logs, then re-train.")
        return

    cfg = TrainConfig(epochs=15, batch_size=64, lr=1e-3)
    model = train_policy(rows, in_dim=feature_dim(), cfg=cfg)
    save_checkpoint(model, "data/policy.pt")
    print("Saved checkpoint to data/policy.pt")


if __name__ == "__main__":
    main()
