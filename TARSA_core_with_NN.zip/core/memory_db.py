import sqlite3
import time
import re
from collections import Counter
from math import sqrt
from core.embeddings import embed
from core.embedding_helper import vector_to_string
from core.embeddings import embed, cosine
from core.embedding_helper import string_to_vector

DB_PATH = "data/tarsa.db"

def init_db():
    """Initialize DB + run lightweight migrations.

    We keep the project runnable even if an older DB already exists.
    """
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    # Main long-term memory table
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS memory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            question TEXT NOT NULL,
            question_norm TEXT NOT NULL,
            lang TEXT NOT NULL,
            answer_full TEXT NOT NULL,
            answer_summary TEXT NOT NULL,
            embedding TEXT NOT NULL,
            created_at INTEGER NOT NULL,
            -- new columns (migrated if missing)
            updated_at INTEGER DEFAULT 0,
            source TEXT DEFAULT 'system',
            confidence REAL DEFAULT 0.5,
            version INTEGER DEFAULT 1,
            is_active INTEGER DEFAULT 1
        )
        """
    )
    cur.execute("CREATE INDEX IF NOT EXISTS idx_qnorm ON memory(question_norm)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_active ON memory(is_active)")

    # Interaction log for training PolicyNet
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS interactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts INTEGER NOT NULL,
            question TEXT NOT NULL,
            lang TEXT NOT NULL,
            exact_found INTEGER NOT NULL,
            best_sim REAL NOT NULL,
            mean_sim REAL NOT NULL,
            std_sim REAL NOT NULL,
            topk INTEGER NOT NULL,
            memory_size INTEGER NOT NULL,
            chosen_action TEXT NOT NULL,
            action_id INTEGER NOT NULL,
            used_oracle INTEGER NOT NULL,
            reward REAL DEFAULT 0.0,
            weight REAL DEFAULT 1.0,
            notes TEXT DEFAULT ''
        )
        """
    )

    # Migration: add missing columns to existing memory table
    cur.execute("PRAGMA table_info(memory)")
    cols = {row[1] for row in cur.fetchall()}
    def add_col(name: str, ddl: str):
        if name not in cols:
            cur.execute(f"ALTER TABLE memory ADD COLUMN {ddl}")

    add_col("updated_at", "updated_at INTEGER DEFAULT 0")
    add_col("source", "source TEXT DEFAULT 'system'")
    add_col("confidence", "confidence REAL DEFAULT 0.5")
    add_col("version", "version INTEGER DEFAULT 1")
    add_col("is_active", "is_active INTEGER DEFAULT 1")

    conn.commit()
    conn.close()


def normalize(text: str) -> str:
    t = text.lower().strip()
    t = re.sub(r"\s+", " ", t)
    return t

def store_qa(question: str, lang: str, answer_full: str, answer_summary: str, source: str = 'ollama', confidence: float = 0.4):
    qn = normalize(question)

    vector = embed(question)                 # 🔥 sentence → vector
    vector_str = vector_to_string(vector)    # 🔥 vector → string

    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    now = int(time.time())
    cur.execute(
        """INSERT INTO memory
        (question, question_norm, lang, answer_full, answer_summary, embedding, created_at, updated_at, source, confidence, version, is_active)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
        (question, qn, lang, answer_full, answer_summary, vector_str, now, now, source, float(confidence), 1, 1)
    )
    conn.commit()
    conn.close()

def get_exact(question: str):
    qn = normalize(question)
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        "SELECT answer_summary, answer_full, confidence, source FROM memory WHERE question_norm=? AND is_active=1 ORDER BY id DESC LIMIT 1",
        (qn,)
    )
    row = cur.fetchone()
    conn.close()
    if row:
        return {"summary": row[0], "full": row[1], "score": 1.0, "confidence": float(row[2]), "source": row[3]}
    return None

def _bow(text: str) -> Counter:
    tokens = re.findall(r"[a-z0-9]+|[\u0980-\u09FF]+", text.lower())
    return Counter(tokens)

def _cosine(a: Counter, b: Counter) -> float:
    if not a or not b:
        return 0.0
    common = set(a) & set(b)
    dot = sum(a[t] * b[t] for t in common)
    na = sqrt(sum(v*v for v in a.values()))
    nb = sqrt(sum(v*v for v in b.values()))
    if na == 0 or nb == 0:
        return 0.0
    return dot / (na * nb)

def get_similar(question: str, min_score: float = 0.75, limit_scan: int = 200):
    q_vec = embed(question)

    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        "SELECT embedding, answer_summary, answer_full, confidence, source FROM memory WHERE is_active=1 ORDER BY id DESC LIMIT ?",
        (limit_scan,)
    )
    rows = cur.fetchall()
    conn.close()

    best = None
    best_score = 0.0

    for emb_str, summ, full, conf, src in rows:
        vec = string_to_vector(emb_str)
        score = cosine(q_vec, vec)
        if score > best_score:
            best_score = score
            best = {"summary": summ, "full": full, "score": score, "confidence": float(conf), "source": src}

    if best and best_score >= min_score:
        return best
    return None


def get_memory_size() -> int:
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT COUNT(1) FROM memory WHERE is_active=1")
    n = int(cur.fetchone()[0])
    conn.close()
    return n


def get_recent_embeddings(limit_scan: int = 50):
    """Return list of recent question embeddings as numpy arrays."""
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        "SELECT embedding FROM memory WHERE is_active=1 ORDER BY id DESC LIMIT ?",
        (int(limit_scan),)
    )
    rows = cur.fetchall()
    conn.close()
    return [string_to_vector(r[0]) for r in rows]


def store_interaction(
    *,
    question: str,
    lang: str,
    exact_found: bool,
    best_sim: float,
    mean_sim: float,
    std_sim: float,
    topk: int,
    memory_size: int,
    chosen_action: str,
    action_id: int,
    used_oracle: bool,
    reward: float = 0.0,
    weight: float = 1.0,
    notes: str = "",
) -> None:
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        """INSERT INTO interactions
        (ts, question, lang, exact_found, best_sim, mean_sim, std_sim, topk, memory_size,
         chosen_action, action_id, used_oracle, reward, weight, notes)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (
            int(time.time()),
            question,
            lang,
            1 if exact_found else 0,
            float(best_sim),
            float(mean_sim),
            float(std_sim),
            int(topk),
            int(memory_size),
            chosen_action,
            int(action_id),
            1 if used_oracle else 0,
            float(reward),
            float(weight),
            notes,
        ),
    )
    conn.commit()
    conn.close()


def load_interactions(limit: int = 5000):
    """Load interactions for training PolicyNet."""
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        """SELECT lang, exact_found, best_sim, mean_sim, std_sim, topk, memory_size, action_id, weight
           FROM interactions ORDER BY id DESC LIMIT ?""",
        (int(limit),)
    )
    rows = cur.fetchall()
    conn.close()
    out = []
    for lang, ex, bs, ms, ss, tk, msz, aid, w in rows:
        # Feature dim must match core.nn.features.feature_dim()
        out.append(
            {
                "features": [0.0, float(ex), float(bs), float(ms), float(ss), float(tk), float(msz)],
                "action_id": int(aid),
                "weight": float(w),
            }
        )
    return out


def deactivate_question(question: str) -> None:
    """Mark all entries for a normalized question as inactive (keeps history)."""
    qn = normalize(question)
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("UPDATE memory SET is_active=0, updated_at=? WHERE question_norm=?", (int(time.time()), qn))
    conn.commit()
    conn.close()


def update_qa(question: str, lang: str, answer_full: str, answer_summary: str, source: str = "user", confidence: float = 0.9):
    """User-editable update: old versions become inactive, new version is inserted."""
    qn = normalize(question)
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT COALESCE(MAX(version), 0) FROM memory WHERE question_norm=?", (qn,))
    prev_ver = int(cur.fetchone()[0] or 0)

    # deactivate old
    cur.execute("UPDATE memory SET is_active=0, updated_at=? WHERE question_norm=?", (int(time.time()), qn))

    vector = embed(question)
    vector_str = vector_to_string(vector)
    now = int(time.time())

    cur.execute(
        """INSERT INTO memory
        (question, question_norm, lang, answer_full, answer_summary, embedding, created_at, updated_at, source, confidence, version, is_active)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
        (question, qn, lang, answer_full, answer_summary, vector_str, now, now, source, float(confidence), prev_ver + 1, 1),
    )
    conn.commit()
    conn.close()
