# TARSA: Neural-Memory AI Assistant (Ollama as Oracle)

This project implements a **hybrid neural memory system** where an **internal trainable neural network** controls:
1) when to answer from internal long‑term memory,  
2) when to ask an external LLM (Ollama) as a **non‑authoritative oracle**, and  
3) how to consolidate newly acquired knowledge into an **editable** memory store.

The external LLM is **never the brain** of the system—only a fallback information source.

---

## 1. Core Idea

Given a user query \(q\), TARSA performs:

1. **Retrieve** from long‑term memory (exact + similarity search).
2. **Neural decision** (PolicyNet): choose action
   - `use_memory`
   - `query_ollama`
   - `ask_clarify`
3. **Uncertainty gating** (entropy + margin): query oracle only when uncertain.
4. **Knowledge consolidation**: store (and later allow user to edit) the consolidated memory.

---

## 2. Architecture Diagram

```mermaid
flowchart TD
  U[User Query q] --> R[Memory Retrieval\n(exact + similarity)]
  R --> F[Feature Builder\nnumeric features]
  F --> P[PolicyNet (MLP)\ntrainable NN]
  P -->|use_memory| M[Answer from Memory]
  P -->|ask_clarify| C[Ask user clarification]
  P -->|query_ollama| O[Ollama Oracle]
  O --> K[Consolidation\n(summary + provenance)]
  K --> S[(Editable Memory DB\nSQLite + Vector embeddings)]
  S --> R
  M --> OUT[Final Answer]
  C --> OUT
  O --> OUT
```

---

## 3. "Real NN" Contribution

### 3.1 Policy Network

We define a trainable policy:

\[
f_\theta(x) \rightarrow \pi(a \mid x)
\]

Where \(x\) is a **numeric feature vector** derived from retrieval signals (not text tokens), e.g.:

- language id
- exact hit (0/1)
- best similarity to recent memory
- mean/std similarity
- memory size

The network outputs logits over actions:

\[
\pi(a\mid x)=\text{softmax}\left(\frac{z_\theta(x)}{T}\right)
\]

### 3.2 Uncertainty-Based Oracle Query

We do not call Ollama by hard rules. We call it when **uncertainty** is high:

Entropy:
\[
H(\pi)=-\sum_i \pi_i \log \pi_i
\]

Margin:
\[
\Delta = \pi_{(1)} - \pi_{(2)}
\]

Oracle is used if:
\[
H(\pi)>\tau_H \quad \text{or} \quad \Delta<\tau_\Delta
\]

This makes the design **defendable mathematically**.

---

## 4. Editable Long-Term Memory

Memory is stored in SQLite (`data/tarsa.db`) with:

- `question`, `question_norm`
- `answer_full`, `answer_summary`
- `embedding` (vector string)
- `source` (user/system/ollama)
- `confidence` (real number)
- `version`, `is_active`

### Update/Edit
User edits do **versioning**:
- old versions are marked `is_active=0`
- a new version is inserted with `version+1`
- embedding is recomputed

See: `core/memory_db.py::update_qa`.

---

## 5. Training Data & Learning

Every interaction is logged into `interactions` table:

- retrieval stats
- action chosen
- whether oracle was used

This creates a dataset:
\[
\{(x_t, a_t, w_t)\}_{t=1}^N
\]

We train PolicyNet via weighted cross entropy:
\[
\mathcal{L} = \frac{1}{N}\sum_t w_t \cdot \text{CE}(\pi_\theta(x_t), a_t)
\]

Weights can reflect:
- user feedback
- trust in oracle output
- correctness (if you later add evaluation labels)

### Train Command

```bash
python -m core.train_policy_cli
```

It saves a checkpoint:
- `data/policy.pt`

---

## 6. Key Files

- `core/brain.py` – orchestration (retrieval → policy → oracle → store)
- `core/nn/policy_net.py` – trainable NN (PolicyNet)
- `core/nn/uncertainty.py` – entropy/margin uncertainty gating
- `core/nn/trainer.py` – training loop
- `core/train_policy_cli.py` – CLI training entry point
- `core/memory_db.py` – memory + interaction logging + edit/versioning

---

## 7. Suggested Experiments (for Professor)

1) **Oracle call rate**: how often Ollama is used  
2) **Memory hit-rate**: exact/similar retrieval coverage  
3) **Ablation**:
   - Baseline A: always call Ollama
   - Baseline B: heuristic thresholds only
   - Proposed: PolicyNet + uncertainty gating

4) **Edit consistency**: after user edits, does retrieval return updated version?

---

## 8. Notes

- The NN is intentionally compact and trainable on laptop.
- The system scales by improving features + better labeling, without needing to retrain a full LLM.
